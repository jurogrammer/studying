package dipviolation;

public class Bishop {

    public void move() {
        System.out.println("대각선으로 이동");
    }
}
