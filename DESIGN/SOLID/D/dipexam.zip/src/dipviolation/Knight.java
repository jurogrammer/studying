package dipviolation;

public class Knight {

    public void move() {
        System.out.println("직선으로 이동");
    }
}
