package dip;

public class Gamer {

    public void movePiece(Piece piece) {
        piece.move();
    }
}
