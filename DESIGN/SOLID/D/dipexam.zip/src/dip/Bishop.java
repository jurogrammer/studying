package dip;

public class Bishop implements Piece{

    @Override
    public void move() {
        System.out.println("대각선으로 이동");
    }
}
