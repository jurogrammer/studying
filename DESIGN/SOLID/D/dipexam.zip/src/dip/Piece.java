package dip;

public interface Piece {
    public void move();
}
