package dip;

public class Knight implements Piece {

    @Override
    public void move() {
        System.out.println("직선으로 이동");
    }
}
