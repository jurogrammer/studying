package adapter.bad;

public class IPhone {
    private String chargeType = "IPhoneType";

    public String getChargeType() {
        return chargeType;
    }
}
