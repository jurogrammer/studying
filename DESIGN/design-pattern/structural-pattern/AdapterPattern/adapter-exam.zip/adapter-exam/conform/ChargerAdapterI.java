package adapter.conform;

public interface ChargerAdapterI {
    public void charge(String chargeType);
}