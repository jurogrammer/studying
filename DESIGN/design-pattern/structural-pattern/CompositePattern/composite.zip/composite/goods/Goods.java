package composite.goods;

public interface Goods {
    int getPrice();
    String getName();
}