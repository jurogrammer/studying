package facade;

public class ImageFacade {
    private RetouchingLibrary retouchingLibrary;
    private CompressLibrary compressLibrary;

    public ImageFacade(RetouchingLibrary retouchingLibrary, CompressLibrary compressLibrary) {
        this.retouchingLibrary = retouchingLibrary;
        this.compressLibrary = compressLibrary;
    }

    public String getUploadingImage(String image) {
        String saturatedImage = retouchingLibrary.adjustSaturation(image, 2);
        String shrinkedImage = retouchingLibrary.shrinkWidth(saturatedImage, 10);
        String compressImage = compressLibrary.compressImage(shrinkedImage, 3);

        return compressImage;
    }
}
