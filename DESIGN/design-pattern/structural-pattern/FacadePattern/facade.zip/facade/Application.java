package facade;

public class Application {
    public static void main(String[] args) {
        ImageFacade imageFacade = new ImageFacade(new RetouchingLibrary(), new CompressLibrary());
        String image = "DogImage";

        System.out.println(imageFacade.getUploadingImage(image));
    }
}