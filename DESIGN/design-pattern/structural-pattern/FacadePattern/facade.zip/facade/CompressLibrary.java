package facade;

public class CompressLibrary {
    public String compressImage(String image, int level) {
        return "compressLevel: " + level + "\n" + image;
    }
}
