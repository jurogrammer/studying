package facade;

public class RetouchingLibrary {
    public String adjustSaturation(String image, int amount) {
        return "saturation: " + amount + "\n" + image;
    }

    public String shrinkWidth(String image, int px) {
        return "shrinkWidth: " +  + px + "\n" + image;
    }
}
