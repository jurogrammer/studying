package builder.baddesign.giantconstructor;

public class Application {
    public static void main(String[] args) {
        Car car = new Car("leatherSeat","v8","niceTripComputer","goodGPS");
    }
}
