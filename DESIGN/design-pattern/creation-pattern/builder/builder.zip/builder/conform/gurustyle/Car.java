package builder.conform.gurustyle;

public class Car {
    private String sheets;
    private String Engine;

    public void setSheets(String sheets) {
        this.sheets = sheets;
    }

    public void setEngine(String engine) {
        Engine = engine;
    }
}
