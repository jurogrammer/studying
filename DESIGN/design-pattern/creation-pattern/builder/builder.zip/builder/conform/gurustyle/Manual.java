package builder.conform.gurustyle;

public class Manual {
    private String sheetsDescription;
    private String EngineDescription;

    public void setSheetsDescription(String sheetsDescription) {
        this.sheetsDescription = sheetsDescription;
    }

    public void setEngineDescription(String engineDescription) {
        EngineDescription = engineDescription;
    }
}
