package abstractfactory.baddesign;

public class RedCircle {

    public void draw() {
        System.out.println("원을 그립니다.");
    }
}