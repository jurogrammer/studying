package abstractfactory.conform.products;

public interface Circle {
    public void render();
}
