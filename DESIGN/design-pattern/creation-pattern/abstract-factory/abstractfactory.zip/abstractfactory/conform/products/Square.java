package abstractfactory.conform.products;

public interface Square {
    public void render();
}
