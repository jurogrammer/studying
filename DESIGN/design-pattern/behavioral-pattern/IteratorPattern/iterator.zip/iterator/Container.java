package iterator;

public interface Container {
    Iterator createDFSIterator();
    Iterator createBFSIterator();
}