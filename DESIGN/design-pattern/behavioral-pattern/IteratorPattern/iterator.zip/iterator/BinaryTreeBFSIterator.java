package iterator;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class BinaryTreeBFSIterator implements Iterator {
    private int currentPosition;
    private List<Integer> cache;
    private BinaryTree binaryTree;

    public BinaryTreeBFSIterator(BinaryTree binaryTree) {
        this.binaryTree = binaryTree;
    }

    @Override
    public int getNext() {
        if (!hasMore()) {
            return Integer.parseInt(null);
        }
        int returnValue = cache.get(currentPosition);
        currentPosition++;

        return returnValue;
    }

    @Override
    public boolean hasMore() {
        lazyInit();
        return currentPosition < cache.size();
    }

    @Override
    public void reset() {
        currentPosition = 0;
    }

    private void lazyInit() {
        if (cache == null) {
            currentPosition = 0;
            setCache();
        }
    }

    private void setCache() {
        if (binaryTree.root == null) {
            return;
        }

        cache = new ArrayList<>();
        Queue<Node> nodes = new LinkedList<>();
        nodes.add(binaryTree.root);

        while (!nodes.isEmpty()) {

            Node node = nodes.remove();

            cache.add(node.value);

            if (node.left != null) {
                nodes.add(node.left);
            }

            if (node.right != null) {
                nodes.add(node.right);
            }
        }
    }

}