package iterator;

public class Application {
    public static void main(String[] args) {
        BinaryTree binaryTree = new BinaryTree();
        binaryTree.add(1);
        binaryTree.add(5);
        binaryTree.add(3);
        binaryTree.add(7);
        binaryTree.add(9);


        Iterator bfsIterator = binaryTree.createBFSIterator();
        Iterator dfsIterator = binaryTree.createDFSIterator();

        System.out.println("bfsIterator");
        while (bfsIterator.hasMore()) {
            System.out.println(bfsIterator.getNext());
        }

        System.out.println("  ");

        System.out.println("dfsIterator");
        while (dfsIterator.hasMore()) {
            System.out.println(dfsIterator.getNext());
        }
    }
}