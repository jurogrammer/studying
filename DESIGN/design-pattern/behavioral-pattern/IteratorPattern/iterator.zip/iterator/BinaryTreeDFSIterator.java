package iterator;

import java.util.ArrayList;
import java.util.List;

public class BinaryTreeDFSIterator implements Iterator{
    private int currentPosition;
    private List<Integer> cache;
    private BinaryTree binaryTree;

    public BinaryTreeDFSIterator(BinaryTree binaryTree) {
        this.binaryTree = binaryTree;
    }

    @Override
    public int getNext() {
        if (!hasMore()) {
            return Integer.parseInt(null);
        }
        int returnValue = cache.get(currentPosition);
        currentPosition++;

        return returnValue;
    }

    @Override
    public boolean hasMore() {
        lazyInit();
        return currentPosition < cache.size();
    }

    @Override
    public void reset() {
        currentPosition = 0;
    }

    private void lazyInit() {
        if (cache == null) {
            setCache();
            currentPosition = 0;
        }
    }

    private void setCache() {
        cache = new ArrayList<>();
        traverseInOrder(binaryTree.root);
    }

    public void traverseInOrder(Node node) {
        if (node != null) {
            traverseInOrder(node.left);
            cache.add(node.value);
            traverseInOrder(node.right);
        }
    }
}

