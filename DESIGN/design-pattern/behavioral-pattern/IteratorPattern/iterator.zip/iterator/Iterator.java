package iterator;

public interface Iterator {
    int getNext();
    boolean hasMore();

    void reset();
}
