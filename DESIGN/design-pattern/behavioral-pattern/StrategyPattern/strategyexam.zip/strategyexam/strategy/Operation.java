package strategyoattern.strategy;

public interface Operation {

    public double execute(double a, double b);
}
