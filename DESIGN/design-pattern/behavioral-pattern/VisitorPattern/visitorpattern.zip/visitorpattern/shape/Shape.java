package visitorpattern.shape;

import visitorpattern.visitor.Visitor;

public interface Shape {
    String accept(Visitor visitor);
}