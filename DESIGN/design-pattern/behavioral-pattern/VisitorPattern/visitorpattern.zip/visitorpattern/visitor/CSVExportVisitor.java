package visitorpattern.visitor;

import visitorpattern.shape.Circle;
import visitorpattern.shape.Rectangle;

public class CSVExportVisitor implements Visitor {
    @Override
    public String visitCircle(Circle circle) {
        return "shape,radius\n" + "circle," + circle.getRadius();
    }

    @Override
    public String visitRectangle(Rectangle rectangle) {
        return "shape,width,height\n" + "rectangle," + rectangle.getWidth() + "," + rectangle.getHeight();
    }
}