package visitorpattern.visitor;

import visitorpattern.shape.Circle;
import visitorpattern.shape.Rectangle;

public interface Visitor {
    String visitCircle(Circle circle);
    String visitRectangle(Rectangle rectangle);
}
