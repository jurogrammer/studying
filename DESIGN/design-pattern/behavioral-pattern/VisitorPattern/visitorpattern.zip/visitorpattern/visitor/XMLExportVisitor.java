package visitorpattern.visitor;

import visitorpattern.shape.Circle;
import visitorpattern.shape.Rectangle;

public class XMLExportVisitor implements Visitor {
    @Override
    public String visitCircle(Circle circle) {
        return "<circle>" + "\n" +
                "    <radius>" + circle.getRadius() + "</radius>" + "\n" +
                "</circle>";
    }

    @Override
    public String visitRectangle(Rectangle rectangle) {
        return "<rectangle>" + "\n" +
                "    <width>" + rectangle.getWidth() + "</width>" + "\n" +
                "    <height>" + rectangle.getHeight() + "</height>" + "\n" +
                "</rectangle>";
    }
}
