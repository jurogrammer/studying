package visitorpattern;

import visitorpattern.shape.Circle;
import visitorpattern.shape.Rectangle;
import visitorpattern.shape.Shape;
import visitorpattern.visitor.CSVExportVisitor;
import visitorpattern.visitor.Visitor;
import visitorpattern.visitor.XMLExportVisitor;

import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        List<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(3));
        shapes.add(new Rectangle(4,5));

        System.out.println("========xmlFormat========");
        for (Shape shape: shapes) {
            System.out.println((shape.accept(new XMLExportVisitor())));
            System.out.println("");
        }

        System.out.println("========csvFormat========");
        for (Shape shape: shapes) {
            System.out.println((shape.accept(new CSVExportVisitor())));
            System.out.println("");
        }
    }
}